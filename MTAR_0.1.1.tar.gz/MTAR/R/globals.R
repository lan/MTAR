utils::globalVariables(c("Y", "indp_snps.1KG", "estLambdaKS", "saddle"))
