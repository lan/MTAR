"estlambda" <- function(data, plot=FALSE, proportion=1.0,
  method="regression", filter=TRUE, df=1,... ) {
  data <- data[which(!is.na(data))]
  if (proportion>1.0 || proportion<=0)
    stop("proportion argument should be greater then zero and less than or equal to one")

  ntp <- round( proportion * length(data) )
  if ( ntp<1 ) stop("no valid measurements")
  if ( ntp==1 ) {
    warning(paste("One measurement, lambda = 1 returned"))
    return(list(estimate=1.0, se=999.99))
  }
  if ( ntp<10 ) warning(paste("number of points is too small:", ntp))
  if ( min(data)<0 ) stop("data argument has values <0")
  if ( max(data)<=1 ) {
    #		lt16 <- (data < 1.e-16)
    #		if (any(lt16)) {
    #			warning(paste("Some probabilities < 1.e-16; set to 1.e-16"))
    #			data[lt16] <- 1.e-16
    #		}
    data <- qchisq(data, 1, lower.tail=FALSE)
  }
  if (filter)
  {
    data[which(abs(data)<1e-8)] <- NA
  }
  data <- sort(data)
  ppoi <- ppoints(data)
  ppoi <- sort(qchisq(ppoi, df=df, lower.tail=FALSE))
  data <- data[1:ntp]
  ppoi <- ppoi[1:ntp]
  #	s <- summary(lm(data~offset(ppoi)))$coeff
  #       bug fix thanks to Franz Quehenberger

  out <- list()
  if (method=="regression") {
    s <- summary( lm(data~0+ppoi) )$coeff
    out$estimate <- s[1,1]
    out$se <- s[1,2]
  } else if (method=="median") {
    out$estimate <- median(data, na.rm=TRUE)/qchisq(0.5, df)
    out$se <- NA
  } else if (method=="KS") {
    limits <- c(0.5, 100)
    out$estimate <- estLambdaKS(data, limits=limits, df=df)
    if ( abs(out$estimate-limits[1])<1e-4 || abs(out$estimate-limits[2])<1e-4 )
      warning("using method='KS' lambda too close to limits, use other method")
    out$se <- NA
  } else {
    stop("'method' should be either 'regression' or 'median'!")
  }

  if (plot) {
    lim <- c(0, max(data, ppoi,na.rm=TRUE))
    #		plot(ppoi,data,xlim=lim,ylim=lim,xlab="Expected",ylab="Observed", ...)
    oldmargins <- par()$mar
    par(mar=oldmargins + 0.2)
    plot(ppoi, data,
      xlab=expression("Expected " ~ chi^2),
      ylab=expression("Observed " ~ chi^2),
      ...)
    abline(a=0, b=1)
    abline(a=0, b=out$estimate, col="red")
    par(mar=oldmargins)
  }

  out
}

lambda1 <- function(p, prob=NULL){
  p <- p[!is.na(p)]
  # estimate lambda
  if(!is.null(prob)){
    p1 <- sapply(prob, function(x) qchisq(quantile(p, prob=x, na.rm = TRUE),
      1, lower.tail = F))
    lambdaVal <- p1/qchisq(1-prob,1)
  }else{
    v1 <- estlambda(p,plot=F, method = "regression", filter = FALSE)
    lambdaVal <- v1$estimate
  }
  return(lambdaVal)
}

remove0.fn <- function(pvalues){
  pvalues[which(pvalues == 0)] <- min(pvalues[which(pvalues != 0)]) / 10
  return(pvalues)
}
qq.plot = function(pvector, title = NULL, include.all.lambda = FALSE, gridlines=F,gridlines.col='gray83',gridlines.lwd=1,gridlines.lty=1,confidence=T,confidence.col='gray81',
                   pt.cex=0.5,pt.col='black',pt.bg='black',pch=21,abline.col='red',abline.lwd=1.8,abline.lty=1,ymax=8,ymax.soft=T,
                   highlight=NULL,highlight.col=c('green3','magenta'),highlight.bg=c('green3','magenta'),
                   annotate=NULL,annotate.cex=0.7,annotate.font=3,cex.axis=0.95,...) {
  #======================================================================================================
  ######## Check data and arguments; create observed and expected distributions
  d = suppressWarnings(as.numeric(pvector))
  names(d) = names(pvector)
  d = d[!is.na(d)] # remove NA, and non-numeric [which were converted to NA during as.numeric()]
  if(any(d == 0)) {
    print("P-values contain zero, replace zero with the value of min(p-values)/10")
  }
  d = remove0.fn(d) ## convert p-values of 0
  d = d[d>0 & d<1] # only Ps between 0 and 1


  if (!is.null(highlight) | !is.null(annotate)){
    if (is.null(names(d))) stop("P-value vector must have names to use highlight or annotate features.")
    d = d[!is.na(names(d))]
    if (!is.null(highlight) & FALSE %in% (highlight %in% names(d))) stop ("D'oh! Highlight vector must be a subset of names(pvector).")
    if (!is.null(annotate) & FALSE %in% (annotate %in% names(d))) stop ("D'oh! Annotate vector must be a subset of names(pvector).")
  }

  d = d[order(d,decreasing=F)] # sort
  o = -log10(d)
  e = -log10( ppoints(length(d) ))
  if (!is.null(highlight) | !is.null(annotate)) names(e) = names(o) = names(d)

  if (!is.numeric(ymax) | ymax<max(o)) ymax <- max(o)

  if (!is.numeric(pt.cex) | pt.cex<0) pt.cex=0.5
  if (!is.numeric(annotate.cex) | annotate.cex<0) annotate.cex=0.7
  if (!is.numeric(annotate.font)) annotate.font=3

  if (is.character(gridlines.col[1]) & !(gridlines.col[1] %in% colors())) gridlines.col = 'gray83'
  if (is.character(confidence.col[1]) & !(confidence.col[1] %in% colors())) confidence.col = 'gray81'
  if (is.character(abline.col[1]) & !(abline.col[1] %in% colors())) abline.col = 'red'

  if (FALSE %in% (pt.col %in% colors() | !is.na(suppressWarnings(as.numeric(pt.col))) )){
    pt.col = 'black'; warning("pt.col argument(s) not recognized. Setting to default: 'black'.")
  }

  if (FALSE %in% (pt.bg %in% colors() | !is.na(suppressWarnings(as.numeric(pt.bg))) )){
    pt.bg = 'black'; warning("pt.bg argument(s) not recognized. Setting to default: 'black'.")
  }

  if (FALSE %in% (highlight.col %in% colors() | !is.na(suppressWarnings(as.numeric(highlight.col))) )){
    highlight.col = 'blue'; warning("highlight.col argument(s) not recognized. Setting to default: 'blue'.")
  }

  if (FALSE %in% (highlight.bg %in% colors() | !is.na(suppressWarnings(as.numeric(highlight.bg))) )){
    highlight.bg = 'blue'; warning("highlight.bg argument(s) not recognized. Setting to default: 'blue'.")
  }

  # Ymax
  if(is.na(suppressWarnings(as.numeric(ymax)))){  # not numeric
    ymax = ceiling(max(o))
    warning('non-numeric ymax argument.')
  } else if (as.numeric(ymax) < 0){           # negative
    ymax = ceiling(max(o))
    warning('negative ymax argument.')
  }
  if (ymax.soft==T){ #if soft, ymax is just the lower limit for ymax
    ymax = max(ymax, ceiling(max(o)))
  } #else, ymax = ymax

  lambdaVal <- round(c(lambda1(pvector, prob = c(0.5, 0.1, 0.01, 1e-3, 1e-4, 1e-5))), 2)
  if(include.all.lambda){
    lambda.exp <- c(bquote(lambda[5e-1] == .(lambdaVal[1])),
                    bquote(lambda[1e-1] == .(lambdaVal[2])),
                    bquote(lambda[1e-2] == .(lambdaVal[3])))
  }else{
    # lambda.exp <- bquote(lambda == .(lambdaVal[1]))
    lambda.exp <- NULL
  }

  ################################

  # Initialize plot
  #print('Setting up plot.')
  #print(ymax)
  xspace = 0.078
  xmax = max(e) * 1.019
  xmin = max(e) * -0.035
  ymax = ceiling(ymax * 1.03)
  ymin = -ymax*0.03
  plot(0,xlab=expression(Expected~~-log[10](italic(p))),ylab=expression(Observed~~-log[10](italic(p))),
       col=F,las=1,xaxt='n',xlim=c(xmin,xmax),ylim=c(ymin,ymax),bty='n',xaxs='i',yaxs='i',cex.axis=cex.axis,main = title, ...)
  axis(side=1,labels=seq(0,max(e),1),at=seq(0,max(e),1),cex.axis=cex.axis,lwd=0,lwd.ticks=1)

  # Grid lines
  if (isTRUE(gridlines)){
    yvals = par('yaxp')
    yticks = seq(yvals[1],yvals[2],yvals[2]/yvals[3])
    abline(v=seq(0,max(e),1),col=gridlines.col[1],lwd=gridlines.lwd,lty=gridlines.lty)
    abline(h=yticks,col=gridlines.col[1],lwd=gridlines.lwd,lty=gridlines.lty)
  }

  #Confidence intervals
  find_conf_intervals = function(row){
    i = row[1]
    len = row[2]
    if (i < 10000 | i %% 100 == 0){
      return(c(-log10(qbeta(0.95,i,len-i+1)), -log10(qbeta(0.05,i,len-i+1))))
    } else { # Speed up
      return(c(NA,NA))
    }
  }

  # Find approximate confidence intervals
  if (isTRUE(confidence)){
    #print('Plotting confidence intervals.')
    ci = apply(cbind( 1:length(e), rep(length(e),length(e))), MARGIN=1, FUN=find_conf_intervals)
    bks = append(seq(5000,length(e),100),length(e)+1)
    for (i in 1:(length(bks)-1)){
      ci[1, bks[i]:(bks[i+1]-1)] = ci[1, bks[i]]
      ci[2, bks[i]:(bks[i+1]-1)] = ci[2, bks[i]]
    }
    colnames(ci) = names(e)
    # Extrapolate to make plotting prettier (doesn't affect intepretation at data points)
    slopes = c((ci[1,1] - ci[1,2]) / (e[1] - e[2]), (ci[2,1] - ci[2,2]) / (e[1] - e[2]))
    extrap_x = append(e[1]+xspace,e) #extrapolate slightly for plotting purposes only
    extrap_y = cbind( c(ci[1,1] + slopes[1]*xspace, ci[2,1] + slopes[2]*xspace), ci)

    polygon(c(extrap_x, rev(extrap_x)), c(extrap_y[1,], rev(extrap_y[2,])),col = confidence.col[1], border = confidence.col[1])
  }

  # Points (with optional highlighting)
  #print('Plotting data points.')
  fills = rep(pt.bg,length(o))
  borders = rep(pt.col,length(o))
  names(fills) = names(borders) = names(o)
  if (!is.null(highlight)){
    borders[highlight] = rep(NA,length(highlight))
    fills[highlight] = rep(NA,length(highlight))
  }
  points(e,o,pch=pch,cex=pt.cex,col=borders,bg=fills)

  if (!is.null(highlight)){
    points(e[highlight],o[highlight],pch=pch,cex=pt.cex,col=highlight.col,bg=highlight.bg)
  }

  #Abline
  abline(0,1,col=abline.col,lwd=abline.lwd,lty=abline.lty)
  abline(h = -log10(0.05/length(pvector)), col = "red", lty = 2)
  if(include.all.lambda){
    yloc <- c(0.9, 0.83, 0.76, 0.69)
    for(lambda.ind in 1:length(lambda.exp)) {
      text(0.6, yloc[lambda.ind] * ymax, as.expression(lambda.exp[lambda.ind]))
    }
  }else{
    text(0.6, 0.9 * ymax, as.expression(lambda.exp))
  }

  # Annotate SNPs
  if (!is.null(annotate)){
    x = e[annotate] # x will definitely be the same
    y = -0.1 + apply(rbind(o[annotate],ci[1,annotate]),2,min)
    text(x,y,labels=annotate,srt=90,cex=annotate.cex,adj=c(1,0.48),font=annotate.font)
  }
  # Box
  box()
}
